﻿var formModule = angular.module('FormModule', ['ngMessages']);

formModule.controller('FormCtl', function ($scope, $http) {

    console.log('Ready');
    $scope.InsModel = {
        InsuranceCode:'', 
        InsuranceId:0,
        Name:'',
        PhoneNo:'',
        Address:'',
        Email:'',
        SumAssured:0,
        Premium:0,
        Nominee: '',
        DateOfService:new Date()
    }

    $scope.submit=function()
    {
        console.log($scope.InsModel);
        $http
        (
        {
            method: 'post',
            datatype: 'jsonp',
            params: { InsData: $scope.InsModel },
            headers: {
                'Content-Type': 'application/json'

            },
            url: 'http://localhost:49365/api/Insurance'

        }
        ).then(function (response)
        {
            console.log(response);
        })


    }

});

