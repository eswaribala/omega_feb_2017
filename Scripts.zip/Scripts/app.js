﻿$(document).ready(function () {
    console.log('Jquery ready');
    $.ajax({
        url: "http://localhost:59155/Insurances",
        type: "GET",
        dataType: 'json',
        success:function(response)
        {
            console.log(response);
            console.log(typeof (response));



            if (typeof (response) != 'object')
                x = JSON.parse(response);
            else
                x = response;

            var row = $('<tr></tr>').appendTo('#HCData')
            $.each(x[0], function (key, value) {
                console.log(key);
                var col = $('<td></td>').text(key).appendTo(row);
            });


            $.each(x,
                function (key, value) {
                    var row = $('<tr></tr>').appendTo('#HCData')
                    $.each(value, function (item, data) {
                        var col = $('<td></td>').text(data).appendTo(row);
                        console.log(data);
                    });
                });

            $('#HCData')
                .tablesorter({
                    theme: 'blue',
                    widget: ['zebra']
                });

            $('#HCData').bdt();


        },
        error:function(err)
        {
            console.log(err);
        }
    });

})