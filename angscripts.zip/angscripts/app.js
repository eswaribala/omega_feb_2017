﻿hcmodule = angular.module('HCModule', ['ConstModule', 'FactoryModule',  'ui.grid.pagination','ui.grid.edit', 'ngAnimate', 'ngTouch', 'ui.grid', 'ui.grid.exporter', 'ui.grid.selection']);
//TranslateProvider = function ($translateProvider) {
//    $translateProvider.translations('en', {
//        'InsuranceId': 'Insurance Id',
//        'Name': 'Name',
//        'SumAssured': 'SumAssured',
//        'Premium': 'Premium'
//    });
//    $translateProvider.translations('ta', {
//        'InsuranceId': 'காப்புறுதி அடையாள எண்',
//        'NAME': 'பெயர்',
//        'SumAssured': 'காப்பீட்டுத் தொகை',
//        'Premium': 'பிரீமியம்'
//    });
//    $translateProvider.preferredLanguage('ta');

//};


//hcmodule.config(['$translateProvider', TranslateProvider]);


hcmodule.controller('Dashboard', ['$scope', 'Options', 'HCFactory', 'i18nService', function ($scope, Options, HCFactory, i18nService) {
    var paginationOptions = {
        pageNumber: 1,
        pageSize: 25,
        sort: null
    };
    $scope.optionalData = Options;
    $scope.selectedValue = "";
    $scope.gridOptions = {};
    $scope.langs = i18nService.getAllLangs();
    console.log(i18nService.getCurrentLang());
    $scope.lang = 'ta';
    //$scope.changeLanguage=function()
    //{
    //    $translate.use($scope.lang);
    //}
    $scope.DataChange=function()
    {
       
        console.log("Selected Value=", $scope.selectedValue);
        var obj = HCFactory.findService($scope.selectedValue);
        
        angular.forEach(obj,function(promise)
        {
           
            promise().then(function(response)
            {
                console.log(response.data);
                $scope.colDefs = [];
                angular.forEach(response.data[0],function(value,key)
                {
                    console.log(key);
                    $scope.colDefs.push({
                        field: key, displayName: key,
                        enableCellEdit: true, width: "*", resizable: false
                    });
                })


                //$scope.hcresult = response.data;

                $scope.gridOptions = {
                    data: response.data,
                    columnDefs: $scope.colDefs,
                    exporterMenuCsv: false,
                    enableGridMenu: true,
                    paginationPageSizes: [5, 10, 15],
                paginationPageSize: 2,
                useExternalPagination: true,
                useExternalSorting: true,
                    
                };


                $scope.gridOptions.onRegisterApi = function (gridApi) {
                    $scope.gridApi2 = gridApi;
                }
               
            })
        })
    }
}
])