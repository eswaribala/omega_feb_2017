﻿var constModule = angular.module('ConstModule', []);
constModule.constant('Options',['Insurance','Inventory','Patient','Users','Roles','Transaction']);