﻿var myApp = angular.module('MyApp', ['angularSpinners']);

myApp.controller('booksController', function ($scope, $http, spinnerService) {
    $scope.loadBooks = function () {
        spinnerService.show('booksSpinner');
        $http.get('https://www.googleapis.com/books/v1/volumes?q=C#')
          .then(function (books) {
              console.log(books.data.items);
              $scope.books = books.data.items;
          })
          .catch(function (err) {
              console.error(err);
          })
          .finally(function () {
              spinnerService.hide('booksSpinner');
          });
    };
});